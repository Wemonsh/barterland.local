<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/test', 'HomeController@test')->name('test');



// Панель администратора
Route::group(['prefix' => 'admin'], function() {

    // Игры
    Route::group(['prefix' => 'game'], function() {
        Route::get('/', 'Admin\GameController@index')->name('game_index');
        Route::get('/create', 'Admin\GameController@create')->name('game_create');
        Route::post('/store', 'Admin\GameController@store')->name('game_store');
        Route::get('/show/{id}', 'Admin\GameController@show')->name('game_show');
        Route::get('/edit/{id}', 'Admin\GameController@edit')->name('game_edit');
        Route::post('/update/{id}', 'Admin\GameController@update')->name('game_update');
        Route::get('/destroy/{id}', 'Admin\GameController@destroy')->name('game_destroy');
    });

    // Услуги
    Route::group(['prefix' => 'service'], function() {
        Route::get('/', 'Admin\ServiceController@index')->name('service_index');
        Route::get('/create', 'Admin\ServiceController@create')->name('service_create');
        Route::post('/store', 'Admin\ServiceController@store')->name('service_store');
        Route::get('/show/{id}', 'Admin\ServiceController@show')->name('service_show');
        Route::get('/edit/{id}', 'Admin\ServiceController@edit')->name('service_edit');
        Route::post('/update/{id}', 'Admin\ServiceController@update')->name('service_update');
        Route::get('/destroy/{id}', 'Admin\ServiceController@destroy')->name('service_destroy');
    });

    // Типы услуг
    Route::group(['prefix' => 'service-type'], function() {

    });

    // Селекты
    Route::group(['prefix' => 'select'], function() {
        Route::get('/', 'Admin\SelectController@index')->name('select_index');
        Route::get('/create', 'Admin\SelectController@create')->name('select_create');
        Route::post('/store', 'Admin\SelectController@store')->name('select_store');
    });

    // Содержимое селектов
    Route::group(['prefix' => 'select-entity'], function() {

    });

    // Пользователи
    Route::group(['prefix' => 'user'], function() {
        // Список пользователей
        Route::get('/', 'Admin\UserController@index')->name('user_index');
        // Редактирование пользователя
        Route::match(['get', 'post'], '/edit/{id}', 'Admin\UserController@edit')->name('user_edit');
    });


    Route::group(['prefix' => 'users'], function() {

        Route::get('/', 'Admin\UserController@index')->name('user_index');
        // Редактировать роли

    });

    Route::group(['prefix' => 'roles'], function() {
        // Список ролей
        Route::get('/', 'Admin\RoleController@index')->name('role_index');
        // Создание роли
        Route::match(['get', 'post'], '/create', 'Admin\RoleController@create')->name('role_create');
        // Редактировать роли
        Route::match(['get', 'post'], '/edit/{id}', 'Admin\RoleController@edit')->name('role_edit');
        // Удалить роли
        Route::get('/delete/{id}', 'Admin\RoleController@delete')->name('role_delete');
    });

    Route::group(['prefix' => 'permissions'], function() {
        // Список разрешений
        Route::get('/', 'Admin\PermissionController@index')->name('permission_index');
        // Создание разрешения
        Route::match(['get', 'post'], '/create', 'Admin\PermissionController@create')->name('permission_create');
        // Редактировать разрешение
        Route::match(['get', 'post'], '/edit/{id}', 'Admin\PermissionController@edit')->name('permission_edit');
        // Удалить разрешение
        Route::get('/delete/{id}', 'Admin\PermissionController@delete')->name('permission_delete');
    });
});

// Единое хранилище документов
Route::group(['prefix' => 'ehd'], function() {
    // Юридические лица
    Route::group(['prefix' => 'legal'], function() {
        // Контрагенты
        Route::group(['prefix' => 'entity'], function() {
            Route::get('/', 'Ehd\LegalEntityController@index')
                ->name('legal_entity_index');
            Route::get('/create', 'Ehd\LegalEntityController@create')
                ->name('legal_entity_create');
            Route::post('/store', 'Ehd\LegalEntityController@store')
                ->name('legal_entity_store');
            Route::get('/show/{id}', 'Ehd\LegalEntityController@show')
                ->name('legal_entity_show');
            Route::get('/edit/{id}', 'Ehd\LegalEntityController@edit')
                ->name('legal_entity_edit');
            Route::post('/update/{id}', 'Ehd\LegalEntityController@update')
                ->name('legal_entity_update');
            Route::get('/destroy/{id}', 'Ehd\LegalEntityController@destroy')
                ->name('legal_entity_destroy');
        });
        // Типы документов
        Route::group(['prefix' => 'type'], function() {
            Route::get('/', 'Ehd\LegalTypeController@index')
                ->name('legal_type_index');
            Route::get('/create', 'Ehd\LegalTypeController@create')
                ->name('legal_type_create');
            Route::post('/store', 'Ehd\LegalTypeController@store')
                ->name('legal_type_store');
            Route::get('/show/{id}', 'Ehd\LegalTypeController@show')
                ->name('legal_type_show');
            Route::get('/edit/{id}', 'Ehd\LegalTypeController@edit')
                ->name('legal_type_edit');
            Route::post('/update/{id}', 'Ehd\LegalTypeController@update')
                ->name('legal_type_update');
            Route::get('/destroy/{id}', 'Ehd\LegalTypeController@destroy')
                ->name('legal_type_destroy');
        });
        // Документы
        Route::group(['prefix' => 'document'], function() {
            Route::get('/', 'Ehd\LegalDocumentController@index')
                ->name('legal_document_index');
            Route::get('/create', 'Ehd\LegalDocumentController@create')
                ->name('legal_document_create');
            Route::post('/store', 'Ehd\LegalDocumentController@store')
                ->name('legal_document_store');
            Route::get('/show/{id}', 'Ehd\LegalDocumentController@show')
                ->name('legal_document_show');
            Route::get('/edit/{id}', 'Ehd\LegalDocumentController@edit')
                ->name('legal_document_edit');
            Route::post('/update/{id}', 'Ehd\LegalDocumentController@update')
                ->name('legal_document_update');
            Route::get('/destroy/{id}', 'Ehd\LegalDocumentController@destroy')
                ->name('legal_document_destroy');
        });
        // Категории документов
        Route::group(['prefix' => 'category'], function() {
            Route::get('/', 'Ehd\LegalCategoryController@index')
                ->name('legal_category_index');
            Route::get('/create', 'Ehd\LegalCategoryController@create')
                ->name('legal_category_create');
            Route::post('/store', 'Ehd\LegalCategoryController@store')
                ->name('legal_category_store');
            Route::get('/show/{id}', 'Ehd\LegalCategoryController@show')
                ->name('legal_category_show');
            Route::get('/edit/{id}', 'Ehd\LegalCategoryController@edit')
                ->name('legal_category_edit');
            Route::post('/update/{id}', 'Ehd\LegalCategoryController@update')
                ->name('legal_category_update');
            Route::get('/destroy/{id}', 'Ehd\LegalCategoryController@destroy')
                ->name('legal_category_destroy');
        });
    });
});









