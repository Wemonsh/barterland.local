<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LegalDocument extends Model
{

    public function category()
    {
        return $this->belongsTo(LegalCategory::class);
    }

    public function type()
    {
        return $this->belongsTo(LegalType::class);
    }

    public function entity()
    {
        return $this->belongsTo(LegalEntity::class);
    }
}
