<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LegalCategory extends Model
{
    public $timestamps = false;

    public function documents()
    {
        return $this->hasMany(LegalDocument::class, 'category_id', 'id');
    }
}
