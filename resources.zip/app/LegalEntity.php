<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LegalEntity extends Model
{
    public function documents()
    {
        return $this->hasMany(LegalDocument::class, 'entity_id', 'id');
    }
}
