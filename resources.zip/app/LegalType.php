<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LegalType extends Model
{
    public $timestamps = false;

    public function documents()
    {
        return $this->hasMany(LegalDocument::class);
    }
}
