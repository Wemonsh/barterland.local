<?php

namespace App\Http\Controllers\Ehd;

use App\Http\Controllers\Controller;
use App\LegalCategory;
use App\LegalDocument;
use App\LegalEntity;
use Illuminate\Http\Request;

class LegalEntityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (view()->exists('ehd.legal.entity.index')) {
            $entities = LegalEntity::paginate(10);
            $vars = [
                'title' => 'Контрагенты',
                'entities' => $entities
            ];
            return view('ehd.legal.entity.index', $vars);
        }
        abort(404);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (view()->exists('ehd.legal.entity.create')) {

            $vars = [
                'title' => 'Создание контрагента',
            ];
            return view('ehd.legal.entity.create', $vars);
        }
        abort(404);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
        ]);

        $game = new LegalEntity();
        $game->name = $request->input('name');
        $game->save();

        return redirect()->route('legal_entity_index');
    }

    /**
     * Display the specified resource.
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        if (view()->exists('ehd.legal.entity.show')) {
            $entity = LegalEntity::find($request->id);

            $dossier = LegalCategory::whereHas('documents', function($q) use ($entity) {
                $q->where('entity_id', '=', $entity->id)->where('type_id', 1);
            })->with(["documents" => function($q) use ($entity) {
                $q->where('entity_id', '=', $entity->id)->where('type_id', 1);
            }])->get();

            $products = LegalCategory::whereHas('documents', function($q) use ($entity) {
                $q->where('entity_id', '=', $entity->id)->where('type_id', 2);
            })->with(["documents" => function($q) use ($entity) {
                $q->where('entity_id', '=', $entity->id)->where('type_id', 2);
            }])->get();

            $vars = [
                'title' => 'Контрагент',
                'entity' => $entity,
                'dossier' => $dossier,
                'products' => $products
            ];

            return view('ehd.legal.entity.show', $vars);
        }
        abort(404);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\LegalEntity  $legalEntity
     * @return \Illuminate\Http\Response
     */
    public function edit(LegalEntity $legalEntity)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\LegalEntity  $legalEntity
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LegalEntity $legalEntity)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\LegalEntity  $legalEntity
     * @return \Illuminate\Http\Response
     */
    public function destroy(LegalEntity $legalEntity)
    {
        //
    }
}
