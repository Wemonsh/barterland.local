<?php

namespace App\Http\Controllers\Ehd;

use App\Http\Controllers\Controller;
use App\LegalCategory;
use Illuminate\Http\Request;

class LegalCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (view()->exists('ehd.legal.category.index')) {
            $categories = LegalCategory::paginate(10);
            $vars = [
                'title' => 'Категории документов',
                'categories' => $categories
            ];
            return view('ehd.legal.category.index', $vars);
        }
        abort(404);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (view()->exists('ehd.legal.category.create')) {

            $vars = [
                'title' => 'Создание категории',
            ];
            return view('ehd.legal.category.create', $vars);
        }
        abort(404);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
        ]);

        $game = new LegalCategory();
        $game->name = $request->input('name');
        $game->save();

        return redirect()->route('legal_category_index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\LegalCategory  $legalCategory
     * @return \Illuminate\Http\Response
     */
    public function show(LegalCategory $legalCategory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\LegalCategory  $legalCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(LegalCategory $legalCategory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\LegalCategory  $legalCategory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LegalCategory $legalCategory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\LegalCategory  $legalCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(LegalCategory $legalCategory)
    {
        //
    }
}
