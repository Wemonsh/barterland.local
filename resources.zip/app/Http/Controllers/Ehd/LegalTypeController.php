<?php

namespace App\Http\Controllers\Ehd;

use App\Http\Controllers\Controller;
use App\LegalType;
use Illuminate\Http\Request;

class LegalTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (view()->exists('ehd.legal.type.index')) {
            $types = LegalType::paginate(10);
            $vars = [
                'title' => 'Типы',
                'types' => $types
            ];
            return view('ehd.legal.type.index', $vars);
        }
        abort(404);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (view()->exists('ehd.legal.type.create')) {

            $vars = [
                'title' => 'Создание типа',
            ];
            return view('ehd.legal.type.create', $vars);
        }
        abort(404);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
        ]);

        $game = new LegalType();
        $game->name = $request->input('name');
        $game->save();

        return redirect()->route('legal_type_index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\LegalType  $legalType
     * @return \Illuminate\Http\Response
     */
    public function show(LegalType $legalType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\LegalType  $legalType
     * @return \Illuminate\Http\Response
     */
    public function edit(LegalType $legalType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\LegalType  $legalType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LegalType $legalType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\LegalType  $legalType
     * @return \Illuminate\Http\Response
     */
    public function destroy(LegalType $legalType)
    {
        //
    }
}
