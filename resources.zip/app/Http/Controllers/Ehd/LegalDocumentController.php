<?php

namespace App\Http\Controllers\Ehd;

use App\Http\Controllers\Controller;
use App\LegalCategory;
use App\LegalDocument;
use App\LegalEntity;
use App\LegalType;
use Illuminate\Http\Request;

class LegalDocumentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (view()->exists('ehd.legal.document.index')) {

            $documents = LegalDocument::with('entity')->with('type')
                ->with('category')->paginate(10);

            $vars = [
                'title' => 'Документы',
                'documents' => $documents
            ];
            return view('ehd.legal.document.index', $vars);
        }
        abort(404);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (view()->exists('ehd.legal.document.create')) {

            $entities = LegalEntity::all();
            $types = LegalType::all();
            $categories = LegalCategory::all();

            $vars = [
                'title' => 'Создание документа',
                'entities' => $entities,
                'types' => $types,
                'categories' => $categories
            ];
            return view('ehd.legal.document.create', $vars);
        }
        abort(404);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
        ]);

        $game = new LegalDocument();
        $game->name = $request->input('name');
        $game->entity_id = $request->input('entity');
        $game->category_id = $request->input('category');
        $game->type_id = $request->input('type');
        $game->save();

        return redirect()->route('legal_document_index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\LegalDocument  $legalDocument
     * @return \Illuminate\Http\Response
     */
    public function show(LegalDocument $legalDocument)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\LegalDocument  $legalDocument
     * @return \Illuminate\Http\Response
     */
    public function edit(LegalDocument $legalDocument)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\LegalDocument  $legalDocument
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LegalDocument $legalDocument)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\LegalDocument  $legalDocument
     * @return \Illuminate\Http\Response
     */
    public function destroy(LegalDocument $legalDocument)
    {
        //
    }
}
