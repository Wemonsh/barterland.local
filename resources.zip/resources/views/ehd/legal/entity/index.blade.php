@extends('layouts.admin')

@section('content')

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">{{ $title }}</h1>
        <a href="{{ route('legal_entity_create') }}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">Добавить котрагента</a>
    </div>

    @if(session()->has('status'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('status') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif

    <table>
        <thead>
            <tr>
                <th>Название</th>
                <th>Действие</th>
            </tr>
        </thead>
        <tbody>
        @foreach($entities as $entity)
            <tr>
                <td>{{ $entity->name }}</td>
                <td>
                    <a href="{{ route('legal_entity_show', $entity->id) }}"><i class="fas fa-eye text-primary"></i></a>
                    <a href="{{ route('legal_entity_edit', $entity->id) }}"><i class="fas fa-edit text-warning"></i></a>
                    <a href="{{ route('legal_entity_destroy', $entity->id) }}"><i class="fas fa-trash-alt text-danger"></i></a>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>

    {{ $entities->links() }}

@endsection

