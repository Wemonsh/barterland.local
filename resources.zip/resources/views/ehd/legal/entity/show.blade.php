@extends('layouts.admin')

@section('content')
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-1 text-gray-800">{{ $title }}</h1>
    </div>



    <div class="row">
        <div class="col-12">
            <div class="card mb-3">
                <div class="card-body">
                    {{ $entity->name }}
                </div>
            </div>
        </div>
        <div class="col-6">

            <h2 class="h4 mb-1 text-gray-800">Досье</h2>

            @foreach($dossier as $value)
                <div class="card shadow mt-1">
                    <a href="#collapseCardDossier{{ $value->id }}" class="d-block card-header py-3 collapsed"
                       data-toggle="collapse" role="button" aria-expanded="false"
                       aria-controls="collapseCardDossier{{ $value->id }}">
                        <h6 class="m-0 font-weight-bold text-primary">{{ $value->name }}</h6>
                    </a>
                    <div class="collapse" id="collapseCardDossier{{ $value->id }}" style="">
                        <ul class="list-group list-group-flush">
                            @foreach($value->documents as $document)
                                <li class="list-group-item">{{ $document->name }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            @endforeach

        </div>
        <div class="col-6">

            <h2 class="h4 mb-1 text-gray-800">Продукты</h2>

            @foreach($products as $value)
                <div class="card shadow mt-1">
                    <a href="#collapseCardProducts{{ $value->id }}" class="d-block card-header py-3 collapsed"
                       data-toggle="collapse" role="button" aria-expanded="false"
                       aria-controls="collapseCardProducts{{ $value->id }}">
                        <h6 class="m-0 font-weight-bold text-primary">{{ $value->name }}</h6>
                    </a>
                    <div class="collapse" id="collapseCardProducts{{ $value->id }}" style="">
                        <ul class="list-group list-group-flush">
                            @foreach($value->documents as $document)
                                <li class="list-group-item">{{ $document->name }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            @endforeach

        </div>
    </div>

@endsection
