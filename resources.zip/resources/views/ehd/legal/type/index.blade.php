@extends('layouts.admin')

@section('content')

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">{{ $title }}</h1>
        <a href="{{ route('legal_type_create') }}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">Добавить тип</a>
    </div>

    @if(session()->has('status'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('status') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif

    <table>
        <thead>
            <tr>
                <th>Название</th>
                <th>Действие</th>
            </tr>
        </thead>
        <tbody>
        @foreach($types as $type)
            <tr>
                <td>{{ $type->name }}</td>
                <td>
                    <a href="{{ route('legal_category_show', $type->id) }}"><i class="fas fa-eye text-primary"></i></a>
                    <a href="{{ route('legal_category_edit', $type->id) }}"><i class="fas fa-edit text-warning"></i></a>
                    <a href="{{ route('legal_category_destroy', $type->id) }}"><i class="fas fa-trash-alt text-danger"></i></a>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>

    {{ $types->links() }}

@endsection

