@extends('layouts.admin')

@section('content')
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-1 text-gray-800">{{ $title }}</h1>
    </div>

    <div class="card">
        <div class="card-body">
            <form action="{{ route('legal_document_store') }}" method="post">
                @csrf

                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <label for="name">Название <span class="text-danger">*</span></label>
                            <input type="text" id="name" name="name" class="form-control @if($errors->has('name')) is-invalid @endif" >
                            {!! $errors->first('name', '<div class="invalid-feedback">Пожалуйста заполните, это поле обязательно для заполнения.</div>') !!}
                        </div>

                        <div class="form-group">
                            <label for="entity">Контрагент</label>
                            <select class="form-control" name="entity" id="entity">
                                @foreach($entities as $entity)
                                    <option value="{{ $entity->id }}">{{ $entity->name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="type">Тип</label>
                            <select class="form-control" name="type" id="type">
                                @foreach($types as $type)
                                    <option value="{{ $type->id }}">{{ $type->name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="category">Категория</label>
                            <select class="form-control" name="category" id="category">
                                @foreach($categories as $category)
                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">Создать</button>
            </form>
        </div>
    </div>

@endsection
