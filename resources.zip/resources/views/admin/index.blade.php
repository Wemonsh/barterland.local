@extends('layouts.admin')

@section('content')
    <h1>123</h1>
@endsection
